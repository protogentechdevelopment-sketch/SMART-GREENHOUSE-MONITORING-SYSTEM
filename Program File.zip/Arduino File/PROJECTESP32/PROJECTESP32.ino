#include <Arduino.h>
#include <DHT.h>
#include <LiquidCrystal_I2C.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <freertos/queue.h>

// ─── Pin Definitions ──────────────────────────────────────
#define IN1 26
#define IN2 27
#define ENA 14

#define BTN1      25
#define BTN2      33
#define BTN_AUTO   5
#define BTN_HOME  18
#define BTN_OPP   19

#define SERVO_PIN         13
#define SOIL_MOISTURE_PIN 34
#define WATER_PUMP_RELAY   4
#define DHT_PIN           15
#define HUMIDITY_RELAY    32
#define LED_PIN           23

#define UART_RX 16
#define UART_TX 17

// ─── Relay / Sensor Config ────────────────────────────────
#define RELAY_ON  HIGH
#define RELAY_OFF LOW

#define DHT_TYPE DHT11
DHT dht(DHT_PIN, DHT_TYPE);

#define SOIL_DRY_THRESHOLD      2000
#define HUMIDITY_LOW_THRESHOLD  40.0

// ─── Servo PWM ────────────────────────────────────────────
const int servoPwmFreq = 50;
const int servoPwmRes  = 16;
const int minDuty      = 1800;
const int maxDuty      = 7800;

// ─── LCD ──────────────────────────────────────────────────
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ─── UART2 ────────────────────────────────────────────────
HardwareSerial plantSerial(2);

// ─────────────────────────────────────────────────────────
// FreeRTOS primitives
// ─────────────────────────────────────────────────────────
SemaphoreHandle_t lcdMutex;
SemaphoreHandle_t sensorMutex;
SemaphoreHandle_t modeMutex;

QueueHandle_t buttonQueue;
QueueHandle_t plantQueue;

// ─────────────────────────────────────────────────────────
// Shared state
// ─────────────────────────────────────────────────────────
struct SensorData {
  int   soilPercent;
  bool  soilDry;
  bool  soilNoSensor;
  float temperature;
  float humidity;
  bool  dhtFail;
  bool  pumpOn;
  bool  humRelayOn;
};
SensorData sData = {0, false, false, 0, 0, false, false, false};

String currentMode     = "IDLE";
String currentStep     = "Waiting...";
String plant1Condition = "";
String plant2Condition = "";

// ADDED: Holds the last UART line received while the capture gate is OPEN.
// Only updated by taskUART when uartCaptureEnabled == true.
// Protected by modeMutex.
String lastUartMessage    = "";    // ADDED

// ADDED: Gate flag — taskUART writes lastUartMessage ONLY when this is true.
// taskMotor opens the gate just before runServoOnLcd() and closes it
// immediately after captureUartAsPlantX(). This ensures UART messages
// received during homing / movement / returnHome are completely ignored.
bool   uartCaptureEnabled = false; // ADDED

// ─── LCD state flags ──────────────────────────────────────
bool   modeCompleted   = false;
int    showPlantResult = 0;
int    idlePage        = 0;

TaskHandle_t sensorTaskHandle = NULL;

// ─────────────────────────────────────────────────────────
// Custom LCD characters
// ─────────────────────────────────────────────────────────
byte charArrow[8] = { 0b00100, 0b00100, 0b00100, 0b00100,
                      0b11111, 0b01110, 0b00100, 0b00000 };
byte charPlant[8] = { 0b00100, 0b01110, 0b11111, 0b00100,
                      0b00100, 0b01110, 0b01100, 0b00000 };

// ─────────────────────────────────────────────────────────
// LCD helpers
// ─────────────────────────────────────────────────────────
String lcdFmt(String s) {
  while ((int)s.length() < 16) s += " ";
  if ((int)s.length() > 16)   s  = s.substring(0, 16);
  return s;
}

void lcdRow(int row, String msg) {
  lcd.setCursor(0, row);
  lcd.print(lcdFmt(msg));
}

void lcdRawRow(int row, const char* buf16) {
  lcd.setCursor(0, row);
  for (int i = 0; i < 16; i++) lcd.write(buf16[i]);
}

void lcdUpdate(String l0, String l1) {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    lcdRow(0, l0);
    lcdRow(1, l1);
    xSemaphoreGive(lcdMutex);
  }
}

void lcdClearUpdate(String l0, String l1) {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
    lcd.clear();
    lcdRow(0, l0);
    lcdRow(1, l1);
    xSemaphoreGive(lcdMutex);
  }
}

// ─────────────────────────────────────────────────────────
// LCD Page renderers
// ─────────────────────────────────────────────────────────

void lcdShowIdleBar() {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) != pdTRUE) return;
  lcd.clear();
  char r0[17]; memset(r0, ' ', 16); r0[16] = 0;
  r0[0]='P'; r0[1]='1';
  r0[7]='P'; r0[8]='2';
  r0[12]='A'; r0[13]='U'; r0[14]='T'; r0[15]='O';
  lcdRawRow(0, r0);
  char r1[17]; memset(r1, ' ', 16); r1[16] = 0;
  r1[0]=(char)0; r1[7]=(char)0; r1[15]=(char)0;
  lcdRawRow(1, r1);
  xSemaphoreGive(lcdMutex);
}

void lcdShowIdleSensor() {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) != pdTRUE) return;
  lcd.clear();
  SensorData d;
  if (xSemaphoreTake(sensorMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    d = sData; xSemaphoreGive(sensorMutex);
  }
  String r0 = d.soilNoSensor ? "Soil:NO SENSOR"
    : "Soil:" + String(d.soilPercent) + "% " + (d.soilDry ? "DRY P:ON" : "WET");
  String r1 = d.dhtFail ? "DHT FAILED!"
    : "T:" + String(d.temperature,1) + "C H:" + String(d.humidity,0) + "%" + (d.humRelayOn?" R:ON":" R:OFF");
  lcdRow(0, r0);
  lcdRow(1, r1);
  xSemaphoreGive(lcdMutex);
}

void lcdShowModeStep(String mode, String step) {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) != pdTRUE) return;
  lcdRow(0, ">" + mode + " MODE");
  lcdRow(1, step);
  xSemaphoreGive(lcdMutex);
}

void lcdShowServoScan(String location) {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) != pdTRUE) return;
  lcd.clear();
  lcdRow(0, "Scanning@" + location);
  lcdRow(1, (char)1 + String(" Processing..."));
  xSemaphoreGive(lcdMutex);
}

void lcdShowPlant1() {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) != pdTRUE) return;
  lcd.clear();
  lcdRow(0, "Plant 1 Status:");
  lcdRow(1, plant1Condition == "" ? "No data yet" : plant1Condition);
  xSemaphoreGive(lcdMutex);
}

void lcdShowPlant2() {
  if (xSemaphoreTake(lcdMutex, pdMS_TO_TICKS(100)) != pdTRUE) return;
  lcd.clear();
  lcdRow(0, "Plant 2 Status:");
  lcdRow(1, plant2Condition == "" ? "No data yet" : plant2Condition);
  xSemaphoreGive(lcdMutex);
}

void lcdShowStartup() {
  lcd.createChar(0, charArrow);
  lcd.createChar(1, charPlant);
  lcd.clear();
  lcdRow(0, "  PLANT SYSTEM  ");
  lcdRow(1, " SMART MONITOR  ");
  vTaskDelay(pdMS_TO_TICKS(1500));
  lcd.clear();
  lcdRow(0, "BTN5  = AUTO    ");
  lcdRow(1, "BTN18 = HOME    ");
  vTaskDelay(pdMS_TO_TICKS(1500));
  lcd.clear();
  lcdRow(0, "BTN19 = OPPOSITE");
  lcdRow(1, "SELECT MODE...  ");
  vTaskDelay(pdMS_TO_TICKS(1500));
  lcd.clear();
  lcdRow(0, "=== READY ===   ");
  lcdRow(1, "Waiting for btn ");
}

// ─────────────────────────────────────────────────────────
// Servo & Motor helpers
// ─────────────────────────────────────────────────────────
int angleToDuty(int angle) { return map(angle, 0, 180, minDuty, maxDuty); }
void servoWrite(int angle)  { ledcWrite(SERVO_PIN, angleToDuty(angle)); }

void runServoSequence() {
  digitalWrite(LED_PIN, HIGH);
  for (int a = 90;  a <= 180; a++) { servoWrite(a); vTaskDelay(pdMS_TO_TICKS(20)); }
  vTaskDelay(pdMS_TO_TICKS(500));
  for (int a = 180; a >= 0;   a--) { servoWrite(a); vTaskDelay(pdMS_TO_TICKS(20)); }
  vTaskDelay(pdMS_TO_TICKS(500));
  for (int a = 0;   a <= 90;  a++) { servoWrite(a); vTaskDelay(pdMS_TO_TICKS(20)); }
  vTaskDelay(pdMS_TO_TICKS(1000));
  digitalWrite(LED_PIN, LOW);
}

void moveRight() { digitalWrite(IN1, HIGH); digitalWrite(IN2, LOW);  ledcWrite(ENA, 165); }
void moveLeft()  { digitalWrite(IN1, LOW);  digitalWrite(IN2, HIGH); ledcWrite(ENA, 165); }
void stopMotor() { digitalWrite(IN1, LOW);  digitalWrite(IN2, LOW);  ledcWrite(ENA, 0);   }

// ─────────────────────────────────────────────────────────
// Motion helpers
// ─────────────────────────────────────────────────────────
void setStep(String s) {
  String mode;
  if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    currentStep = s; mode = currentMode; xSemaphoreGive(modeMutex);
  }
  lcdShowModeStep(mode, s);
}

void goHomeOnStart() {
  Serial.println("Homing...");
  setStep("Homing LEFT");
  moveLeft();
  while (true) {
    if (digitalRead(BTN1) == LOW) {
      stopMotor(); setStep("Home Reached!");
      Serial.println("BTN1 — Home reached!");
      vTaskDelay(pdMS_TO_TICKS(300)); return;
    }
    if (digitalRead(BTN2) == LOW) {
      stopMotor(); setStep("BTN2! Rev RIGHT");
      vTaskDelay(pdMS_TO_TICKS(300));
      moveRight();
      while (true) {
        if (digitalRead(BTN1) == LOW) {
          stopMotor(); setStep("Home Reached!");
          Serial.println("BTN1 — Home reached!");
          vTaskDelay(pdMS_TO_TICKS(300)); return;
        }
        vTaskDelay(pdMS_TO_TICKS(10));
      }
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void goToPosition2() {
  Serial.println("Moving to Pos2...");
  setStep("Moving RIGHT");
  moveRight();
  while (true) {
    if (digitalRead(BTN2) == LOW) {
      stopMotor(); setStep("Pos2 Reached!");
      Serial.println("BTN2 — Position 2 reached!");
      vTaskDelay(pdMS_TO_TICKS(300)); return;
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void returnHome() {
  Serial.println("Returning Home...");
  setStep("Return LEFT");
  moveLeft();
  while (true) {
    if (digitalRead(BTN1) == LOW) {
      stopMotor(); setStep("Back at Home!");
      Serial.println("BTN1 — Back at home!");
      vTaskDelay(pdMS_TO_TICKS(300)); return;
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void runServoOnLcd(String location) {
  setStep("Servo @ " + location);
  Serial.println("Servo sweep @ " + location);
  lcdShowServoScan(location);
  runServoSequence();
  String mode;
  if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
    mode = currentMode; xSemaphoreGive(modeMutex);
  }
  lcdShowModeStep(mode, "Scan done @" + location);
}

// ─────────────────────────────────────────────────────────
// ADDED: Open the UART capture gate.
// Called by taskMotor just BEFORE runServoOnLcd() so that only
// UART messages arriving during the servo sweep are recorded.
// During all movement phases (homing, travel, return) the gate
// stays closed and taskUART ignores incoming lines.
// ─────────────────────────────────────────────────────────
void openUartCapture() {                                                 // ADDED
  if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {        // ADDED
    lastUartMessage    = "";       // clear stale data from prior moves  // ADDED
    uartCaptureEnabled = true;                                           // ADDED
    xSemaphoreGive(modeMutex);                                          // ADDED
  }                                                                      // ADDED
  Serial.println("[UART GATE] OPEN — capturing scan UART only");        // ADDED
}                                                                        // ADDED

// ─────────────────────────────────────────────────────────
// ADDED: Close the UART capture gate and snapshot the captured
// message into plant1Condition. Gate closes immediately so any
// UART traffic during returnHome() or onward travel is discarded.
// ─────────────────────────────────────────────────────────
void closeUartCaptureAsPlant1() {                                        // ADDED
  if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(100)) == pdTRUE) {       // ADDED
    uartCaptureEnabled = false;                                          // ADDED
    if (lastUartMessage.length() > 0) {                                  // ADDED
      plant1Condition = lastUartMessage;                                 // ADDED
      Serial.println("[CAPTURE] P1 locked: " + plant1Condition);        // ADDED
    }                                                                    // ADDED
    xSemaphoreGive(modeMutex);                                          // ADDED
  }                                                                      // ADDED
  Serial.println("[UART GATE] CLOSED after Plant 1 scan");              // ADDED
}                                                                        // ADDED

// ─────────────────────────────────────────────────────────
// ADDED: Close the UART capture gate and snapshot the captured
// message into plant2Condition.
// ─────────────────────────────────────────────────────────
void closeUartCaptureAsPlant2() {                                        // ADDED
  if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(100)) == pdTRUE) {       // ADDED
    uartCaptureEnabled = false;                                          // ADDED
    if (lastUartMessage.length() > 0) {                                  // ADDED
      plant2Condition = lastUartMessage;                                 // ADDED
      Serial.println("[CAPTURE] P2 locked: " + plant2Condition);        // ADDED
    }                                                                    // ADDED
    xSemaphoreGive(modeMutex);                                          // ADDED
  }                                                                      // ADDED
  Serial.println("[UART GATE] CLOSED after Plant 2 scan");              // ADDED
}                                                                        // ADDED

// ─────────────────────────────────────────────────────────
// TASK 1 — Button Task (Core 1, Priority 3)
// ─────────────────────────────────────────────────────────
void taskButtons(void* pv) {
  int prevAuto = LOW, prevHome = LOW, prevOpp = LOW;
  for (;;) {
    int btnAuto = digitalRead(BTN_AUTO);
    int btnHome = digitalRead(BTN_HOME);
    int btnOpp  = digitalRead(BTN_OPP);

    if (btnAuto == HIGH && prevAuto == LOW) {
      vTaskDelay(pdMS_TO_TICKS(50));
      if (digitalRead(BTN_AUTO) == HIGH) { uint8_t cmd=1; xQueueSend(buttonQueue,&cmd,0); Serial.println("BTN5 — AUTO queued"); }
    }
    if (btnHome == HIGH && prevHome == LOW) {
      vTaskDelay(pdMS_TO_TICKS(50));
      if (digitalRead(BTN_HOME) == HIGH) { uint8_t cmd=2; xQueueSend(buttonQueue,&cmd,0); Serial.println("BTN18 — HOME queued"); }
    }
    if (btnOpp == HIGH && prevOpp == LOW) {
      vTaskDelay(pdMS_TO_TICKS(50));
      if (digitalRead(BTN_OPP) == HIGH)  { uint8_t cmd=3; xQueueSend(buttonQueue,&cmd,0); Serial.println("BTN19 — OPP queued"); }
    }

    prevAuto = btnAuto; prevHome = btnHome; prevOpp = btnOpp;
    vTaskDelay(pdMS_TO_TICKS(20));
  }
}

// ─────────────────────────────────────────────────────────
// TASK 2 — Motor/Mode Task (Core 1, Priority 2)
// ─────────────────────────────────────────────────────────
void taskMotor(void* pv) {
  uint8_t cmd;
  for (;;) {
    if (xQueueReceive(buttonQueue, &cmd, portMAX_DELAY) == pdTRUE) {

      if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        modeCompleted = false; showPlantResult = 0; idlePage = 0;
        xSemaphoreGive(modeMutex);
      }

      String modeName = (cmd == 1) ? "AUTO" : (cmd == 2) ? "HOME" : "OPP";
      if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        currentMode = modeName; xSemaphoreGive(modeMutex);
      }

      lcdClearUpdate("=" + modeName + " MODE=", "Starting...");
      vTaskDelay(pdMS_TO_TICKS(600));

      // ────────────────────────────────────────────────────
      // AUTO: scan Plant1 at Home, scan Plant2 at Pos2
      // Gate opens ONLY during each servo sweep window.
      // Gate closes (locking the value) before any movement.
      // ────────────────────────────────────────────────────
      if (cmd == 1) {
        Serial.println("=== AUTO MODE STARTED ===");
        goHomeOnStart();
        openUartCapture();           // ADDED — gate OPEN: servo sweep starts
        runServoOnLcd("Home");
        closeUartCaptureAsPlant1();  // ADDED — gate CLOSED: P1 locked, movement begins
        goToPosition2();
        openUartCapture();           // ADDED — gate OPEN: servo sweep starts
        runServoOnLcd("Pos2");
        closeUartCaptureAsPlant2();  // ADDED — gate CLOSED: P2 locked, movement begins
        returnHome();
        Serial.println("=== AUTO MODE COMPLETE ===");

      // ────────────────────────────────────────────────────
      // HOME: scan Plant1 at Home only
      // ────────────────────────────────────────────────────
      } else if (cmd == 2) {
        Serial.println("=== HOME MODE STARTED ===");
        goHomeOnStart();
        openUartCapture();           // ADDED — gate OPEN: servo sweep starts
        runServoOnLcd("Home");
        closeUartCaptureAsPlant1();  // ADDED — gate CLOSED: P1 locked
        Serial.println("=== HOME MODE COMPLETE ===");

      // ────────────────────────────────────────────────────
      // OPP: scan Plant2 at Pos2 only
      // ────────────────────────────────────────────────────
      } else if (cmd == 3) {
        Serial.println("=== OPPOSITE MODE STARTED ===");
        goHomeOnStart();
        goToPosition2();
        openUartCapture();           // ADDED — gate OPEN: servo sweep starts
        runServoOnLcd("Pos2");
        closeUartCaptureAsPlant2();  // ADDED — gate CLOSED: P2 locked, movement begins
        returnHome();                // gate already closed — return travel ignored
        Serial.println("=== OPPOSITE MODE COMPLETE ===");
      }

      servoWrite(90);

      lcdClearUpdate(modeName + " COMPLETE!", "Reading plants..");
      vTaskDelay(pdMS_TO_TICKS(1000));

      // Show LCD results per mode:
      //   AUTO → P1 (3s) then P2 (3s)
      //   HOME → P1 only (3s)
      //   OPP  → P2 only (3s)
      if (cmd == 1) {
        lcdShowPlant1();
        vTaskDelay(pdMS_TO_TICKS(3000));
        lcdShowPlant2();
        vTaskDelay(pdMS_TO_TICKS(3000));
      } else if (cmd == 2) {
        lcdShowPlant1();
        vTaskDelay(pdMS_TO_TICKS(3000));
      } else if (cmd == 3) {
        lcdShowPlant2();
        vTaskDelay(pdMS_TO_TICKS(3000));
      }

      if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        currentMode = "IDLE"; currentStep = "Waiting...";
        modeCompleted = false; showPlantResult = 0; idlePage = 0;
        xSemaphoreGive(modeMutex);
      }

      if (sensorTaskHandle != NULL) xTaskNotifyGive(sensorTaskHandle);
    }
  }
}

// ─────────────────────────────────────────────────────────
// TASK 3 — Sensor Task (Core 0, Priority 1)
// ─────────────────────────────────────────────────────────
void taskSensors(void* pv) {
  for (;;) {
    long total = 0;
    for (int i = 0; i < 10; i++) {
      total += analogRead(SOIL_MOISTURE_PIN);
      vTaskDelay(pdMS_TO_TICKS(10));
    }
    int soilValue   = total / 10;
    int soilPercent = map(soilValue, 4095, 0, 0, 100);

    Serial.println("========================================");
    Serial.println("         SOIL MOISTURE SENSOR          ");
    Serial.print("  Raw ADC    : "); Serial.println(soilValue);
    Serial.print("  Moisture   : "); Serial.print(soilPercent); Serial.println(" %");

    bool soilNoSensor = (soilValue == 4095);
    bool soilDry      = (soilValue > SOIL_DRY_THRESHOLD);
    bool pumpOn       = false;

    if (soilNoSensor) {
      digitalWrite(WATER_PUMP_RELAY, RELAY_OFF);
      Serial.println("  Status     : SENSOR NOT CONNECTED — Pump OFF");
    } else if (soilDry) {
      digitalWrite(WATER_PUMP_RELAY, RELAY_ON);
      pumpOn = true;
      Serial.println("  Status     : DRY — Pump ON");
    } else {
      digitalWrite(WATER_PUMP_RELAY, RELAY_OFF);
      Serial.println("  Status     : WET/OK — Pump OFF");
    }
    Serial.println("========================================");

    float humidity    = dht.readHumidity();
    float temperature = dht.readTemperature();

    Serial.println("========================================");
    Serial.println("           DHT SENSOR READINGS         ");
    bool dhtFail    = false;
    bool humRelayOn = false;

    if (isnan(humidity) || isnan(temperature)) {
      Serial.println("  DHT Read FAILED");
      dhtFail = true;
      digitalWrite(HUMIDITY_RELAY, RELAY_OFF);
    } else {
      Serial.print("  Temperature : "); Serial.print(temperature); Serial.println(" C");
      Serial.print("  Humidity    : "); Serial.print(humidity);    Serial.println(" %");
      if (humidity < HUMIDITY_LOW_THRESHOLD) {
        digitalWrite(HUMIDITY_RELAY, RELAY_ON);
        humRelayOn = true;
        Serial.println("  Status      : HUMIDITY LOW — Relay ON");
      } else {
        digitalWrite(HUMIDITY_RELAY, RELAY_OFF);
        Serial.println("  Status      : Humidity Normal — Relay OFF");
      }
    }
    Serial.println("========================================");

    if (xSemaphoreTake(sensorMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      sData.soilPercent  = soilPercent;
      sData.soilDry      = soilDry;
      sData.soilNoSensor = soilNoSensor;
      sData.pumpOn       = pumpOn;
      sData.dhtFail      = dhtFail;
      if (!dhtFail) { sData.temperature = temperature; sData.humidity = humidity; }
      sData.humRelayOn = humRelayOn;
      xSemaphoreGive(sensorMutex);
    }

    ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(2000));
  }
}

// ─────────────────────────────────────────────────────────
// TASK 4 — UART Task (Core 0, Priority 1)
// ─────────────────────────────────────────────────────────
void taskUART(void* pv) {
  for (;;) {
    if (plantSerial.available()) {
      String incoming = plantSerial.readStringUntil('\n');
      incoming.trim();
      if (incoming.length() > 0) {
        Serial.print("[PLANT UART]: "); Serial.println(incoming);

        // ADDED: Write lastUartMessage ONLY when the capture gate is open.
        // Gate is opened by taskMotor just before runServoOnLcd() and closed
        // right after — so UART received during homing / travel / returnHome
        // is completely discarded and cannot corrupt the plant readings.
        if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) { // ADDED
          if (uartCaptureEnabled) {                                     // ADDED
            lastUartMessage = incoming;                                 // ADDED
            Serial.println("[UART GATE] Captured: " + incoming);       // ADDED
          } else {                                                      // ADDED
            Serial.println("[UART GATE] BLOCKED (movement): " + incoming); // ADDED
          }                                                             // ADDED
          xSemaphoreGive(modeMutex);                                   // ADDED
        }                                                               // ADDED

        if (incoming.startsWith("P1:")) {
          String cond = incoming.substring(3); cond.trim();
          if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
            plant1Condition = cond; xSemaphoreGive(modeMutex);
          }
          Serial.println("  → Saved P1: " + cond);
        } else if (incoming.startsWith("P2:")) {
          String cond = incoming.substring(3); cond.trim();
          if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
            plant2Condition = cond; xSemaphoreGive(modeMutex);
          }
          Serial.println("  → Saved P2: " + cond);
        } else {
          char buf[33];
          incoming.substring(0, 32).toCharArray(buf, 33);
          xQueueSend(plantQueue, buf, 0);
        }
      }
    }
    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

// ─────────────────────────────────────────────────────────
// TASK 5 — LCD Task (Core 0, Priority 1)
// ─────────────────────────────────────────────────────────
void taskLCD(void* pv) {
  TickType_t lastWake = xTaskGetTickCount();
  for (;;) {
    char buf[33];
    if (xQueueReceive(plantQueue, buf, 0) == pdTRUE) {
      if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
        plant1Condition = String(buf); xSemaphoreGive(modeMutex);
      }
    }

    String mode;
    if (xSemaphoreTake(modeMutex, pdMS_TO_TICKS(50)) == pdTRUE) {
      mode = currentMode; xSemaphoreGive(modeMutex);
    }

    if (mode != "IDLE") {
      vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(500));
      continue;
    }

    if (idlePage == 0) lcdShowIdleBar();
    else               lcdShowIdleSensor();
    idlePage = (idlePage + 1) % 2;

    vTaskDelayUntil(&lastWake, pdMS_TO_TICKS(3000));
  }
}

// ─────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(500);

  pinMode(WATER_PUMP_RELAY, OUTPUT);
  pinMode(HUMIDITY_RELAY,   OUTPUT);
  pinMode(LED_PIN,          OUTPUT);
  digitalWrite(WATER_PUMP_RELAY, RELAY_OFF);
  digitalWrite(HUMIDITY_RELAY,   RELAY_OFF);
  digitalWrite(LED_PIN,          LOW);

  Wire.begin(21, 22);
  lcd.init();
  lcd.backlight();
  lcd.createChar(0, charArrow);
  lcd.createChar(1, charPlant);

  plantSerial.begin(9600, SERIAL_8N1, UART_RX, UART_TX);

  pinMode(IN1,      OUTPUT);
  pinMode(IN2,      OUTPUT);
  pinMode(BTN1,     INPUT_PULLUP);
  pinMode(BTN2,     INPUT_PULLUP);
  pinMode(BTN_AUTO, INPUT_PULLUP);
  pinMode(BTN_HOME, INPUT_PULLUP);
  pinMode(BTN_OPP,  INPUT_PULLUP);

  ledcAttach(ENA,       5000,         8);
  ledcAttach(SERVO_PIN, servoPwmFreq, servoPwmRes);

  analogSetAttenuation(ADC_11db);
  analogReadResolution(12);
  dht.begin();
  servoWrite(90);
  delay(500);

  lcdShowStartup();

  lcdMutex    = xSemaphoreCreateMutex();
  sensorMutex = xSemaphoreCreateMutex();
  modeMutex   = xSemaphoreCreateMutex();
  buttonQueue = xQueueCreate(5, sizeof(uint8_t));
  plantQueue  = xQueueCreate(3, 33 * sizeof(char));

  xTaskCreatePinnedToCore(taskButtons, "Buttons", 2048, NULL, 3, NULL,              1);
  xTaskCreatePinnedToCore(taskMotor,   "Motor",   4096, NULL, 2, NULL,              1);
  xTaskCreatePinnedToCore(taskSensors, "Sensors", 3072, NULL, 1, &sensorTaskHandle, 0);
  xTaskCreatePinnedToCore(taskUART,    "UART",    2048, NULL, 1, NULL,              0);
  xTaskCreatePinnedToCore(taskLCD,     "LCD",     3072, NULL, 1, NULL,              0);

  Serial.println("=== SYSTEM READY — FreeRTOS running ===");
  Serial.println("Press BTN5  → AUTO");
  Serial.println("Press BTN18 → HOME");
  Serial.println("Press BTN19 → OPP");
}

void loop() { vTaskDelete(NULL); }